export type MemoryKey =
  | 'customerName'
  | 'country'
  | 'currency'
  | 'deliveryAddress'
  | 'productName'
  | 'model'
  | 'material'
  | 'size'
  | 'color'
  | 'packaging'
  | 'paymentTerms'
  | 'leadTime'
  | 'validityPeriod'

export interface MemoryItem {
  value: string
  updatedAt: number
}

const STORAGE_KEY = 'lammap-param-memory-v1'
const MAX_ITEMS_PER_KEY = 30

function loadAll(): Record<string, MemoryItem[]> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return {}
    const parsed = JSON.parse(raw) as Record<string, MemoryItem[]>
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch {
    return {}
  }
}

function saveAll(all: Record<string, MemoryItem[]>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
  } catch {
    // ignore
  }
}

export function rememberValue(key: MemoryKey, raw: unknown) {
  const v = String(raw ?? '').trim()
  if (!v) return
  const now = Date.now()
  const all = loadAll()
  const list = Array.isArray(all[key]) ? all[key] : []
  const existingIdx = list.findIndex((x) => x.value.toLowerCase() === v.toLowerCase())
  if (existingIdx >= 0) {
    list[existingIdx] = { value: list[existingIdx].value, updatedAt: now }
  } else {
    list.unshift({ value: v, updatedAt: now })
  }
  list.sort((a, b) => b.updatedAt - a.updatedAt)
  all[key] = list.slice(0, MAX_ITEMS_PER_KEY)
  saveAll(all)
}

export function getSuggestions(key: MemoryKey, query: string): string[] {
  const q = (query || '').trim().toLowerCase()
  const all = loadAll()
  const list = Array.isArray(all[key]) ? all[key] : []
  const sorted = [...list].sort((a, b) => b.updatedAt - a.updatedAt)
  const filtered = q
    ? sorted.filter((x) => x.value.toLowerCase().includes(q))
    : sorted
  return filtered.map((x) => x.value)
}

